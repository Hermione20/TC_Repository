#ifndef __CONTROL_TASK_H
#define __CONTROL_TASK_H
#include "public.h"







void control_task(void);
void control_task_Init(void);

extern int time_tick;







#endif

